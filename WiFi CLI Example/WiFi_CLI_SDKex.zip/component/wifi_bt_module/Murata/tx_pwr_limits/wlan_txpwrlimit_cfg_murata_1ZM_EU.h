/** @file wlan_txpwrlimit_cfg_murata_1ZM_EU
 *
 *  @brief  This file provides Murata 1ZM WLAN EU Tx Power Limit APIs.
 *
 *  Copyright 2022 Murata Manufacturing Co., Ltd.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, this
 *  list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  3. Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software without
 *  specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 */
static wlan_chanlist_t chanlist_2g_cfg = {.num_chans = 13,
                                          .chan_info = {
                                              [0] =
                                                  {
                                                      .chan_num                     = 1,
                                                      .chan_freq                    = 2412,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [1] =
                                                  {
                                                      .chan_num                     = 2,
                                                      .chan_freq                    = 2417,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [2] =
                                                  {
                                                      .chan_num                     = 3,
                                                      .chan_freq                    = 2422,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [3] =
                                                  {
                                                      .chan_num                     = 4,
                                                      .chan_freq                    = 2427,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [4] =
                                                  {
                                                      .chan_num                     = 5,
                                                      .chan_freq                    = 2432,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [5] =
                                                  {
                                                      .chan_num                     = 6,
                                                      .chan_freq                    = 2437,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [6] =
                                                  {
                                                      .chan_num                     = 7,
                                                      .chan_freq                    = 2442,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [7] =
                                                  {
                                                      .chan_num                     = 8,
                                                      .chan_freq                    = 2447,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [8] =
                                                  {
                                                      .chan_num                     = 9,
                                                      .chan_freq                    = 2452,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [9] =
                                                  {
                                                      .chan_num                     = 10,
                                                      .chan_freq                    = 2457,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [10] =
                                                  {
                                                      .chan_num                     = 11,
                                                      .chan_freq                    = 2462,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [11] =
                                                  {
                                                      .chan_num                     = 12,
                                                      .chan_freq                    = 2467,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [12] =
                                                  {
                                                      .chan_num                     = 13,
                                                      .chan_freq                    = 2472,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [13] = {0},
                                              [14] = {0},
                                              [15] = {0},
                                              [16] = {0},
                                              [17] = {0},
                                              [18] = {0},
                                              [19] = {0},
                                              [20] = {0},
                                              [21] = {0},
                                              [22] = {0},
                                              [23] = {0},
                                              [24] = {0},
                                              [25] = {0},
                                              [26] = {0},
                                              [27] = {0},
                                              [28] = {0},
                                              [29] = {0},
                                              [30] = {0},
                                              [31] = {0},
                                              [32] = {0},
                                              [33] = {0},
                                              [34] = {0},
                                              [35] = {0},
                                              [36] = {0},
                                              [37] = {0},
                                              [38] = {0},
                                              [39] = {0},
                                              [40] = {0},
                                              [41] = {0},
                                              [42] = {0},
                                              [43] = {0},
                                              [44] = {0},
                                              [45] = {0},
                                              [46] = {0},
                                              [47] = {0},
                                              [48] = {0},
                                              [49] = {0},
                                              [50] = {0},
                                              [51] = {0},
                                              [52] = {0},
                                              [53] = {0},
                                          }};

#ifdef CONFIG_5GHz_SUPPORT
static wlan_chanlist_t chanlist_5g_cfg = {.num_chans = 24,
                                          .chan_info = {
                                              [0] =
                                                  {
                                                      .chan_num                     = 36,
                                                      .chan_freq                    = 5180,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [1] =
                                                  {
                                                      .chan_num                     = 40,
                                                      .chan_freq                    = 5200,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [2] =
                                                  {
                                                      .chan_num                     = 44,
                                                      .chan_freq                    = 5220,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [3] =
                                                  {
                                                      .chan_num                     = 48,
                                                      .chan_freq                    = 5240,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [4] =
                                                  {
                                                      .chan_num                     = 52,
                                                      .chan_freq                    = 5260,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [5] =
                                                  {
                                                      .chan_num                     = 56,
                                                      .chan_freq                    = 5280,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [6] =
                                                  {
                                                      .chan_num                     = 60,
                                                      .chan_freq                    = 5300,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [7] =
                                                  {
                                                      .chan_num                     = 64,
                                                      .chan_freq                    = 5320,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [8] =
                                                  {
                                                      .chan_num                     = 100,
                                                      .chan_freq                    = 5500,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [9] =
                                                  {
                                                      .chan_num                     = 104,
                                                      .chan_freq                    = 5520,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [10] =
                                                  {
                                                      .chan_num                     = 108,
                                                      .chan_freq                    = 5540,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [11] =
                                                  {
                                                      .chan_num                     = 112,
                                                      .chan_freq                    = 5560,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [12] =
                                                  {
                                                      .chan_num                     = 116,
                                                      .chan_freq                    = 5580,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [13] =
                                                  {
                                                      .chan_num                     = 120,
                                                      .chan_freq                    = 5600,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [14] =
                                                  {
                                                      .chan_num                     = 124,
                                                      .chan_freq                    = 5620,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [15] =
                                                  {
                                                      .chan_num                     = 128,
                                                      .chan_freq                    = 5640,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [16] =
                                                  {
                                                      .chan_num                     = 132,
                                                      .chan_freq                    = 5660,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [17] =
                                                  {
                                                      .chan_num                     = 136,
                                                      .chan_freq                    = 5680,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [18] =
                                                  {
                                                      .chan_num                     = 140,
                                                      .chan_freq                    = 5700,
                                                      .passive_scan_or_radar_detect = true,
                                                  },
                                              [19] =
                                                  {
                                                      .chan_num                     = 149,
                                                      .chan_freq                    = 5745,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [20] =
                                                  {
                                                      .chan_num                     = 153,
                                                      .chan_freq                    = 5765,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [21] =
                                                  {
                                                      .chan_num                     = 157,
                                                      .chan_freq                    = 5785,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [22] =
                                                  {
                                                      .chan_num                     = 161,
                                                      .chan_freq                    = 5805,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [23] =
                                                  {
                                                      .chan_num                     = 165,
                                                      .chan_freq                    = 5825,
                                                      .passive_scan_or_radar_detect = false,
                                                  },
                                              [24] = {0},
                                              [25] = {0},
                                              [26] = {0},
                                              [27] = {0},
                                              [28] = {0},
                                              [29] = {0},
                                              [30] = {0},
                                              [31] = {0},
                                              [32] = {0},
                                              [33] = {0},
                                              [34] = {0},
                                              [35] = {0},
                                              [36] = {0},
                                              [37] = {0},
                                              [38] = {0},
                                              [39] = {0},
                                              [40] = {0},
                                              [41] = {0},
                                              [42] = {0},
                                              [43] = {0},
                                              [44] = {0},
                                              [45] = {0},
                                              [46] = {0},
                                              [47] = {0},
                                              [48] = {0},
                                              [49] = {0},
                                              [50] = {0},
                                              [51] = {0},
                                              [52] = {0},
                                              [53] = {0},
                                          }};
#endif

#ifndef CONFIG_11AC
static wifi_txpwrlimit_t
    tx_pwrlimit_2g_cfg =
        {.subband   = (wifi_SubBand_t)0x00,
         .num_chans = 13,
         .txpwrlimit_config =
             {
                 [0] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 1,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 0}, {8, 0}, {9, 0}},
                     },
                 [1] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 2,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 0}, {8, 0}, {9, 0}},
                     },
                 [2] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 3,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [3] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 4,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [4] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 5,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [5] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 6,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [6] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 7,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [7] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 8,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [8] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 9,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [9] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 10,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [10] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 11,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                     },
                 [11] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 12,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 0}, {8, 0}, {9, 0}},
                     },
                 [12] =
                     {
                         .num_mod_grps = 10,
                         .chan_desc =
                             {
                                 .start_freq = 2407,
                                 .chan_width = 20,
                                 .chan_num   = 13,
                             },
                         .txpwrlimit_entry =
                             {{0, 14}, {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14}, {6, 14}, {7, 0}, {8, 0}, {9, 0}},
                     },
                 [13] = {0},
                 [14] = {0},
                 [15] = {0},
                 [16] = {0},
                 [17] = {0},
                 [18] = {0},
                 [19] = {0},
                 [20] = {0},
                 [21] = {0},
                 [22] = {0},
                 [23] = {0},
                 [24] = {0},
                 [25] = {0},
                 [26] = {0},
                 [27] = {0},
                 [28] = {0},
                 [29] = {0},
                 [30] = {0},
                 [31] = {0},
                 [32] = {0},
                 [33] = {0},
                 [34] = {0},
                 [35] = {0},
                 [36] = {0},
                 [37] = {0},
                 [38] = {0},
                 [39] = {0},
             }};

#ifdef CONFIG_5GHz_SUPPORT
static wifi_txpwrlimit_t tx_pwrlimit_5g_cfg =
    {
        .subband   = (wifi_SubBand_t)0x00,
        .num_chans = 25,
        .txpwrlimit_config =
            {
                [0] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 36,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [1] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 40,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [2] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 44,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [3] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 48,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [4] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 52,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [5] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 56,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [6] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 60,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [7] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 64,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [8] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 100,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [9] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 104,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [10] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 108,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [11] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 112,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [12] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 116,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [13] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 120,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [14] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 124,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [15] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 128,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [16] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 132,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [17] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 136,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 14}, {8, 14}, {9, 14}},
                    },
                [18] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 140,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 15}, {2, 15}, {3, 15}, {4, 14}, {5, 14}, {6, 14}, {7, 0}, {8, 0}, {9, 0}},
                    },
                [19] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 144,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 0}, {2, 0}, {3, 0}, {4, 0}, {5, 0}, {6, 0}, {7, 0}, {8, 0}, {9, 0}},
                    },
                [20] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 149,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 7}, {2, 7}, {3, 7}, {4, 7}, {5, 7}, {6, 7}, {7, 7}, {8, 7}, {9, 7}},
                    },
                [21] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 153,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 7}, {2, 7}, {3, 7}, {4, 7}, {5, 7}, {6, 7}, {7, 7}, {8, 7}, {9, 7}},
                    },
                [22] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 157,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 7}, {2, 7}, {3, 7}, {4, 7}, {5, 7}, {6, 7}, {7, 7}, {8, 7}, {9, 7}},
                    },
                [23] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 161,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 7}, {2, 7}, {3, 7}, {4, 7}, {5, 7}, {6, 7}, {7, 7}, {8, 7}, {9, 7}},
                    },
                [24] =
                    {
                        .num_mod_grps = 10,
                        .chan_desc =
                            {
                                .start_freq = 5000,
                                .chan_width = 20,
                                .chan_num   = 165,
                            },
                        .txpwrlimit_entry =
                            {{0, 0}, {1, 7}, {2, 7}, {3, 7}, {4, 7}, {5, 7}, {6, 7}, {7, 7}, {8, 7}, {9, 7}},
                    },
                [25] = {0},
                [26] = {0},
                [27] = {0},
                [28] = {0},
                [29] = {0},
                [30] = {0},
                [31] = {0},
                [32] = {0},
                [33] = {0},
                [34] = {0},
                [35] = {0},
                [36] = {0},
                [37] = {0},
                [38] = {0},
                [39] = {0},
            }};
#endif
#else
static wifi_txpwrlimit_t tx_pwrlimit_2g_cfg = {.subband   = (wifi_SubBand_t)0x00,
                                               .num_chans = 13,
                                               .txpwrlimit_config =
                                                   {
                                                       [0] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 1,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [1] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 2,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [2] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 3,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [3] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 4,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [4] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 5,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [5] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 6,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [6] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 7,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [7] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 8,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [8] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 9,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [9] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 10,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [10] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 11,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [11] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 12,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [12] =
                                                           {
                                                               .num_mod_grps = 12,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 2407,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 13,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 14},
                                                                                    {1, 14},
                                                                                    {2, 14},
                                                                                    {3, 14},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 0},
                                                                                    {8, 0},
                                                                                    {9, 0},
                                                                                    {10, 14},
                                                                                    {11, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0},
                                                                                    {0, 0}},
                                                           },
                                                       [13] = {0},
                                                       [14] = {0},
                                                       [15] = {0},
                                                       [16] = {0},
                                                       [17] = {0},
                                                       [18] = {0},
                                                       [19] = {0},
                                                       [20] = {0},
                                                       [21] = {0},
                                                       [22] = {0},
                                                       [23] = {0},
                                                       [24] = {0},
                                                       [25] = {0},
                                                       [26] = {0},
                                                       [27] = {0},
                                                       [28] = {0},
                                                       [29] = {0},
                                                       [30] = {0},
                                                       [31] = {0},
                                                       [32] = {0},
                                                       [33] = {0},
                                                       [34] = {0},
                                                       [35] = {0},
                                                       [36] = {0},
                                                       [37] = {0},
                                                       [38] = {0},
                                                       [39] = {0},
                                                   }};

#ifdef CONFIG_5GHz_SUPPORT
static wifi_txpwrlimit_t tx_pwrlimit_5g_cfg = {.subband   = (wifi_SubBand_t)0x00,
                                               .num_chans = 24,
                                               .txpwrlimit_config =
                                                   {
                                                       [0] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 36,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 0},
                                                                                    {1, 15},
                                                                                    {2, 15},
                                                                                    {3, 15},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 14},
                                                                                    {8, 14},
                                                                                    {9, 14},
                                                                                    {10, 14},
                                                                                    {11, 13},
                                                                                    {12, 14},
                                                                                    {13, 13},
                                                                                    {14, 13},
                                                                                    {15, 13}},
                                                           },
                                                       [1] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 40,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 0},
                                                                                    {1, 15},
                                                                                    {2, 15},
                                                                                    {3, 15},
                                                                                    {4, 14},
                                                                                    {5, 14},
                                                                                    {6, 14},
                                                                                    {7, 14},
                                                                                    {8, 14},
                                                                                    {9, 14},
                                                                                    {10, 14},
                                                                                    {11, 13},
                                                                                    {12, 14},
                                                                                    {13, 13},
                                                                                    {14, 13},
                                                                                    {15, 13}},
                                                           },
                                                       [2] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 44,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [3] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 48,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [4] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 52,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [5] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 56,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [6] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 60,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [7] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 64,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [8] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 100,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [9] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 104,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [10] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 108,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [11] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 112,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [12] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 116,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [13] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 120,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [14] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 124,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [15] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 128,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 14},
                                                                    {13, 13},
                                                                    {14, 13},
                                                                    {15, 13}},
                                                           },
                                                       [16] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 132,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 0},
                                                                    {13, 0},
                                                                    {14, 0},
                                                                    {15, 0}},
                                                           },
                                                       [17] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 136,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 14},
                                                                    {8, 14},
                                                                    {9, 14},
                                                                    {10, 14},
                                                                    {11, 13},
                                                                    {12, 0},
                                                                    {13, 0},
                                                                    {14, 0},
                                                                    {15, 0}},
                                                           },
                                                       [18] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 140,
                                                                   },
                                                               .txpwrlimit_entry =
                                                                   {{0, 0},
                                                                    {1, 15},
                                                                    {2, 15},
                                                                    {3, 15},
                                                                    {4, 14},
                                                                    {5, 14},
                                                                    {6, 14},
                                                                    {7, 0},
                                                                    {8, 0},
                                                                    {9, 0},
                                                                    {10, 14},
                                                                    {11, 0},
                                                                    {12, 0},
                                                                    {13, 0},
                                                                    {14, 0},
                                                                    {15, 0}},
                                                           },
                                                       [19] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 149,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 0},
                                                                                    {1, 7},
                                                                                    {2, 7},
                                                                                    {3, 7},
                                                                                    {4, 7},
                                                                                    {5, 7},
                                                                                    {6, 7},
                                                                                    {7, 7},
                                                                                    {8, 7},
                                                                                    {9, 7},
                                                                                    {10, 7},
                                                                                    {11, 7},
                                                                                    {12, 7},
                                                                                    {13, 7},
                                                                                    {14, 7},
                                                                                    {15, 7}},
                                                           },
                                                       [20] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 153,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 0},
                                                                                    {1, 7},
                                                                                    {2, 7},
                                                                                    {3, 7},
                                                                                    {4, 7},
                                                                                    {5, 7},
                                                                                    {6, 7},
                                                                                    {7, 7},
                                                                                    {8, 7},
                                                                                    {9, 7},
                                                                                    {10, 7},
                                                                                    {11, 7},
                                                                                    {12, 7},
                                                                                    {13, 7},
                                                                                    {14, 7},
                                                                                    {15, 7}},
                                                           },
                                                       [21] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 157,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 0},
                                                                                    {1, 7},
                                                                                    {2, 7},
                                                                                    {3, 7},
                                                                                    {4, 7},
                                                                                    {5, 7},
                                                                                    {6, 7},
                                                                                    {7, 7},
                                                                                    {8, 7},
                                                                                    {9, 7},
                                                                                    {10, 7},
                                                                                    {11, 7},
                                                                                    {12, 7},
                                                                                    {13, 7},
                                                                                    {14, 7},
                                                                                    {15, 7}},
                                                           },
                                                       [22] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 161,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 0},
                                                                                    {1, 7},
                                                                                    {2, 7},
                                                                                    {3, 7},
                                                                                    {4, 7},
                                                                                    {5, 7},
                                                                                    {6, 7},
                                                                                    {7, 7},
                                                                                    {8, 7},
                                                                                    {9, 7},
                                                                                    {10, 7},
                                                                                    {11, 7},
                                                                                    {12, 7},
                                                                                    {13, 7},
                                                                                    {14, 7},
                                                                                    {15, 7}},
                                                           },
                                                       [23] =
                                                           {
                                                               .num_mod_grps = 16,
                                                               .chan_desc =
                                                                   {
                                                                       .start_freq = 5000,
                                                                       .chan_width = 20,
                                                                       .chan_num   = 165,
                                                                   },
                                                               .txpwrlimit_entry = {{0, 0},
                                                                                    {1, 7},
                                                                                    {2, 7},
                                                                                    {3, 7},
                                                                                    {4, 7},
                                                                                    {5, 7},
                                                                                    {6, 7},
                                                                                    {7, 7},
                                                                                    {8, 7},
                                                                                    {9, 7},
                                                                                    {10, 7},
                                                                                    {11, 7},
                                                                                    {12, 0},
                                                                                    {13, 0},
                                                                                    {14, 0},
                                                                                    {15, 0}},
                                                           },
                                                       [24] = {0},
                                                       [25] = {0},
                                                       [26] = {0},
                                                       [27] = {0},
                                                       [28] = {0},
                                                       [29] = {0},
                                                       [30] = {0},
                                                       [31] = {0},
                                                       [32] = {0},
                                                       [33] = {0},
                                                       [34] = {0},
                                                       [35] = {0},
                                                       [36] = {0},
                                                       [37] = {0},
                                                       [38] = {0},
                                                       [39] = {0},
                                                   }};
#endif /* CONFIG_5GHz_SUPPORT */
#endif /* CONFIG_11AC */
